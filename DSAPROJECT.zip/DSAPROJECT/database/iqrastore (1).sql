-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2024 at 07:20 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iqrastore`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `userId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` text NOT NULL,
  `Category` text NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`userId`, `productId`, `productName`, `Category`, `price`) VALUES
(530, 3, 'Shirt 1', '', 5000),
(530, 4, 'Shirt 2', '', 5000),
(530, 5, 'Shirt 3', '', 5000),
(530, 7, 'Shirt 5', '', 5000),
(530, 3, 'Shirt 1', '', 5000),
(828, 3, 'Shirt 1', '', 5000),
(828, 5, 'Shirt 3', '', 5000),
(828, 4, 'Shirt 2', '', 5000),
(174, 3, 'Shirt 1', 'Clothing', 5000),
(174, 7, 'Shirt 5', 'Clothing', 5000),
(416, 3, 'Shirt 1', 'Clothing', 5000),
(416, 4, 'Shirt 2', 'Clothing', 5000),
(416, 9, 'Cricket Gloves ', 'Sports', 3600),
(24, 3, 'Shirt 1', 'Clothing', 5000),
(24, 7, 'Shirt 5', 'Clothing', 5000),
(24, 9, 'Cricket Gloves ', 'Sports', 3600),
(24, 4, 'Shirt 2', 'Clothing', 5000),
(24, 8, 'Cricket Bat ', 'Sports', 3000),
(743, 3, 'Shirt 1', 'Clothing', 5000),
(743, 5, 'Shirt 3', 'Clothing', 5000),
(743, 7, 'Shirt 5', 'Clothing', 5000),
(458, 3, 'Shirt 1', 'Clothing', 5000),
(458, 5, 'Shirt 3', 'Clothing', 5000),
(458, 4, 'Shirt 2', 'Clothing', 5000),
(547, 3, 'Shirt 1', 'Clothing', 5000),
(547, 7, 'Shirt 5', 'Clothing', 5000),
(547, 9, 'Cricket Gloves ', 'Sports', 3600),
(99, 3, 'Shirt 1', 'Clothing', 5000),
(99, 4, 'Shirt 2', 'Clothing', 5000),
(596, 4, 'Shirt 2', 'Clothing', 5000),
(596, 9, 'Cricket Gloves ', 'Sports', 3600),
(561, 3, 'Shirt 1', 'Clothing', 5000),
(561, 9, 'Cricket Gloves ', 'Sports', 3600),
(579, 3, 'Shirt 1', 'Clothing', 5000),
(579, 5, 'Shirt 3', 'Clothing', 5000),
(607, 3, 'Shirt 1', 'Clothing', 5000),
(607, 9, 'Cricket Gloves ', 'Sports', 3600),
(562, 3, 'Shirt 1', 'Clothing', 5000),
(562, 5, 'Shirt 3', 'Clothing', 5000),
(621, 3, 'Shirt 1', 'Clothing', 5000),
(621, 7, 'Shirt 5', 'Clothing', 5000),
(74, 3, 'Shirt 1', 'Clothing', 5000),
(776, 7, 'Shirt 5', 'Clothing', 5000),
(776, 4, 'Shirt 2', 'Clothing', 5000),
(870, 3, 'Shirt 1', 'Clothing', 5000),
(870, 4, 'Shirt 2', 'Clothing', 5000),
(870, 5, 'Shirt 3', 'Clothing', 5000),
(870, 4, 'Shirt 2', 'Clothing', 5000),
(697, 3, 'Shirt 1', 'Clothing', 5000),
(697, 5, 'Shirt 3', 'Clothing', 5000),
(379, 4, 'Shirt 2', 'Clothing', 5000),
(379, 7, 'Shirt 5', 'Clothing', 5000),
(379, 8, 'Cricket Bat ', 'Sports', 3000),
(718, 3, 'Shirt 1', 'Clothing', 5000),
(718, 4, 'Shirt 2', 'Clothing', 5000),
(85, 4, 'Shirt 2', 'Clothing', 5000),
(551, 3, 'Shirt 1', 'Clothing', 5000),
(551, 7, 'Shirt 5', 'Clothing', 5000),
(410, 3, 'Shirt 1', 'Clothing', 5000),
(410, 9, 'Cricket Gloves ', 'Sports', 3600),
(410, 5, 'Shirt 3', 'Clothing', 5000),
(410, 3, 'Shirt 1', 'Clothing', 5000),
(230, 24, 'Ring', 'Accessories', 549),
(230, 22, 'Chain', 'Accessories', 1299),
(230, 4, 'Shirt 2', 'Clothing', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `customerid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `number` int(11) NOT NULL,
  `city` text NOT NULL,
  `address` text NOT NULL,
  `total` int(11) NOT NULL,
  `status` text NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`customerid`, `userid`, `name`, `email`, `number`, `city`, `address`, `total`, `status`) VALUES
(1, 776, 'jbchsbhd', 'nsdbshb', 767676, 'bhdgs', 'bhbhdbf', 10000, 'pending'),
(2, 870, 'Shadab', 'shadabakhund14@gmail.com', 326226, 'dcscsgfh', 'nacvhgcjhbxhcwgd', 20000, 'pending'),
(3, 697, 'Kumail', 'dnhabdja', 87273872, 'djsbdj', 'jsdksdisdskjds', 10000, 'pending'),
(4, 379, 'ajsh', 'jsdbsb', 545454, 'ncjsnxj', 'njxcbjkbcksb', 13000, 'pending'),
(5, 718, 'wdhushf', 'xnjfj', 545454, 'sfsf', 'djsbjsbdjs', 10000, 'delivered'),
(6, 85, 'nshdjshdj', 'jxbcjsbj', 4515454, 'jcbdjb', 'njdbcksnbckjsbc', 5000, 'Delivered'),
(7, 551, 'gfgdgdf', 'fgdgd', 454545, 'gdgdgd', 'xgdgdgdgd', 10000, 'delivered'),
(8, 230, 'Shadab', 'shadabakhund14@gmail.com', 3102776, 'Karachi', 'Karachi, Pakistan', 6848, 'delivered');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `Category` text NOT NULL,
  `price` int(11) NOT NULL,
  `Stock` int(11) NOT NULL,
  `imageUrl` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `Category`, `price`, `Stock`, `imageUrl`) VALUES
(4, 'Shirt 2', 'Clothing', 5000, 300, 'product\\2.jpg'),
(5, 'Shirt 3', 'Clothing', 5000, 300, 'product\\3.jpg'),
(6, 'Shirt 4', 'Clothing', 5000, 300, 'product\\4.jpg'),
(7, 'Shirt 5', 'Clothing', 5000, 300, 'product\\5.jpg'),
(8, 'Cricket Bat ', 'Sports', 3000, 300, 'product\\sports1.jpg'),
(9, 'Cricket Gloves ', 'Sports', 3600, 300, 'product\\sports2.jpg'),
(10, 'Kumail', 'Sports', 400, 20, 'product\\staff.jpg'),
(11, 'Kit Bag', 'Sports', 9999, 5, 'product\\sports kit bag.jpg'),
(12, 'Wickets', 'Sports', 4999, 3, 'product\\Wicket.jpg'),
(13, 'Helmet', 'Sports', 6499, 10, 'product\\Helmet.jpg'),
(14, 'Charger', 'Electronics', 349, 12, 'product\\Electronic1.jpg'),
(15, 'Hand-Free', 'Electronics', 549, 12, 'product\\Electronic2.jpg'),
(16, 'Headphone', 'Electronics', 1299, 5, 'product\\Electronic3.jpg'),
(17, 'Speaker', 'Electronics', 4599, 3, 'product\\Electronic4.jpg'),
(18, 'Mouse', 'Electronics', 799, 12, 'product\\Electronic5.jpg'),
(19, 'Keyboard', 'Electronics', 1249, 12, 'product\\Electronic6.jpg'),
(20, 'Braceket', 'Accessories', 999, 12, 'product\\Acc Bracelet.jpg'),
(21, 'Braceket', 'Accessories', 999, 12, 'product\\Acc Bracelet1.jpg'),
(22, 'Chain', 'Accessories', 1299, 12, 'product\\Acc Chain.jpg'),
(23, 'Locket With Chain', 'Accessories', 1549, 12, 'product\\Acc Locketchain.jpg'),
(24, 'Ring', 'Accessories', 549, 12, 'product\\Acc Ring.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `customerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
