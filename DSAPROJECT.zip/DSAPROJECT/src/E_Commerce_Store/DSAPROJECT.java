package E_Commerce_Store;

import javax.swing.JFrame;
import javax.swing.Timer;


public class DSAPROJECT {

    public static void main(String[] args) {
        
        JFrame firstFrame = new SPLASH_SCREEN();
     JFrame secondFrame = new Clothing();

        //Set Timer of Splash Screen for 1 Seconds
       secondFrame.setVisible(false);
        // event listener 3 sec (3000)
        Timer timer = new Timer(2000, e -> {
            firstFrame.setVisible(false);
            if (firstFrame.isActive()) {
               secondFrame.setVisible(true);
            }
        });

        //Splash Screen Visibe than timer hide Splash screen and run FirstScreen
        firstFrame.setVisible(true);
        timer.start();

    }

}
